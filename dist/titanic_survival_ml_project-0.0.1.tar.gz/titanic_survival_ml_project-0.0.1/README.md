# Example Package

This is a simple example machine learning project package.